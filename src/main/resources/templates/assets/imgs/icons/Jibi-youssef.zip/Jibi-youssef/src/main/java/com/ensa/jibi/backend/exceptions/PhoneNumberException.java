package com.ensa.jibi.backend.exceptions;

public class PhoneNumberException extends RuntimeException {
    public PhoneNumberException(String message) {
        super(message);
    }
}
