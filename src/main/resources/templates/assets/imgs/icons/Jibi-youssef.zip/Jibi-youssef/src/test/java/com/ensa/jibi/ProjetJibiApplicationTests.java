package com.ensa.jibi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetJibiApplicationTests {

	@Test
	void contextLoads() {
	}

}
