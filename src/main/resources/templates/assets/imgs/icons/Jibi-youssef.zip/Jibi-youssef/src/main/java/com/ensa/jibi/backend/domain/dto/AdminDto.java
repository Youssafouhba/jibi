package com.ensa.jibi.backend.domain.dto;

import lombok.*;

@Data
@EqualsAndHashCode(callSuper = true)
public class AdminDto extends UserDto{
}
