export interface DocumentDto {
  docUrl: string;
  description: string;
}
