export interface ComptePaiementDto {
  id: string;
  solde: number;
  // Add other properties as defined in your Java DTO
}
