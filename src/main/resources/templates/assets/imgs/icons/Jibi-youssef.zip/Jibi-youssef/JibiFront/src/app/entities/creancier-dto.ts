export interface CreancierDto {
  id: number;
  nom: string;
  categorie: string;
  logoURL: string;
}
