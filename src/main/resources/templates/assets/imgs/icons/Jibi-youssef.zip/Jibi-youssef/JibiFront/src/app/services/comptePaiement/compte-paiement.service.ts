import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
import {ComptePaiementDto} from "../../entities/comptePaiement-dto";
import {environment} from "../../../environments/environment.development";

interface TransferRequest {
  fromAccount: string;
  toAccount: string;
  amount: number;
}
@Injectable({
  providedIn: 'root'
})
export class ComptePaiementService {

  private baseUrl = 'http://localhost:8080/api/comptePaiements';
  private jsonHttpOptions: { headers: HttpHeaders } = environment.jsonHttpOptions;

  constructor(private http: HttpClient) { }

  createComptePaiement(comptePaiementDto: ComptePaiementDto): Observable<ComptePaiementDto> {
    return this.http.post<ComptePaiementDto>(this.baseUrl, comptePaiementDto,this.jsonHttpOptions);
  }

  getComptePaiement(id: string): Observable<ComptePaiementDto> {
    return this.http.get<ComptePaiementDto>(`${this.baseUrl}/${id}`,this.jsonHttpOptions);
  }

  getAllComptePaiements(): Observable<ComptePaiementDto[]> {
    return this.http.get<ComptePaiementDto[]>(this.baseUrl,this.jsonHttpOptions);
  }

  partialUpdateComptePaiement(id: string, comptePaiementDto: ComptePaiementDto): Observable<ComptePaiementDto> {
    return this.http.patch<ComptePaiementDto>(`${this.baseUrl}/${id}`, comptePaiementDto,this.jsonHttpOptions);
  }

  payer(id: string, creanceId: number, montant: number): Observable<ComptePaiementDto> {
    let params = new HttpParams()
      .set('creanceId', creanceId.toString())
      .set('montant', montant.toString());
    return this.http.post<ComptePaiementDto>(`${this.baseUrl}/${id}/payer`, {}, { params });
  }

  deleteComptePaiement(id: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`,this.jsonHttpOptions);
  }

  rechargeSolde(id: string, montant: number): Observable<ComptePaiementDto> {
    let params = new HttpParams().set('montant', montant.toString());
    return this.http.post<ComptePaiementDto>(`${this.baseUrl}/${id}/recharge`, {}, { params });
  }

  transferSolde(transferRequest: TransferRequest): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}/transfer`, transferRequest,this.jsonHttpOptions);
  }

}
