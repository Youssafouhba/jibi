# Jibi
this is a school project for a invoice  payement soulution
