export enum ClientType {
  Hsab_1 = 'Hsab_1',
  Hsab_2 = 'Hsab_2',
  Hsab_3 = 'Hsab_3',
  Hsab_PRO = 'Hsab_PRO'
}
