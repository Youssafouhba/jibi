package com.ensa.jibi.cmi.domain.enums;

public enum ImpayeType {
    FRAIS,
    PENALITE,
    SIMPLE
}
